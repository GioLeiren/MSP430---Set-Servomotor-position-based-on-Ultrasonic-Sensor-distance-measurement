#include <msp430.h>
#include "libs/leds.h"
#include "libs/sensor.h"
#include "libs/servomotor.h"

volatile unsigned int timer_val;
int servoPos;

void distFunction(float distance);

void main(void)
{
    WDTCTL = WDTPW | WDTHOLD;   // stop watchdog timer

    ledsConfig();
    sensorConfig();
    Servo_Config();

    volatile float distance;

    __enable_interrupt();

    while(1){
        distance = sensorTriggerPulse();
        __delay_cycles(5000);
        distFunction(distance);
    }
}

void distFunction(float distance){
    if (distance < 10){
        P1OUT &= ~BIT0;
        P4OUT &= ~BIT7;
        servoPos = (int)distance;
        Servo_SetPosition(servoPos);
    }
    else if (distance >= 10 && distance < 30){
        P1OUT &= ~BIT0;
        P4OUT |= BIT7;
        servoPos = (int)distance;
        Servo_SetPosition(servoPos);
    }
    else if (distance >= 30 && distance < 50){
        P1OUT |= BIT0;
        P4OUT &= ~BIT7;
        servoPos = (int)distance;
        Servo_SetPosition(servoPos);
    }
    else if (distance >= 50){
        P1OUT |= BIT0;
        P4OUT |= BIT7;
        servoPos = (int)distance;
        Servo_SetPosition(servoPos);
    }
}

#pragma vector=TIMER2_A1_VECTOR
__interrupt void TIMER2_A1_ISR(void)
{
    switch(TA2IV)
    {
    case TA2IV_TACCR1: // Capture mode
        timer_val = TA2CCR1;
        break;
    default:
        break;
    }
}
