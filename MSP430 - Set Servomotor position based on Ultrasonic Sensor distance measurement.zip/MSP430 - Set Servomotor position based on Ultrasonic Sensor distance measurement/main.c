#include <msp430.h>
#include "libs/leds.h"
#include "libs/sensor.h"
#include "libs/servomotor.h"

volatile unsigned int timer_val;

void distFunction(float distance);

void main(void)
{
    WDTCTL = WDTPW | WDTHOLD;   // stop watchdog timer

    ledsConfig();
    sensorConfig();
    Servo_Config();

    __enable_interrupt();

    while(1){
        sensorTriggerPulse();

        // Calcular a dist�ncia
        volatile float distance = (float)timer_val / 58.0;
        distFunction(distance);
    }
}

void distFunction(float distance){
    if (distance < 10){
        P1OUT &= ~BIT0;
        P4OUT &= ~BIT7;
    }
    else if (distance >= 10 && distance < 30){
        P1OUT &= ~BIT0;
        P4OUT |= BIT7;
    }
    else if (distance >= 30 && distance < 50){
        P1OUT |= BIT0;
        P4OUT &= ~BIT7;
    }
    else{
        P1OUT |= BIT0;
        P4OUT |= BIT7;
    }
}

#pragma vector=TIMER0_A1_VECTOR
__interrupt void TIMER0_A1_ISR(void)
{
    switch(TA0IV)
    {
    case TA0IV_TACCR1: // Capture mode
        timer_val = TA0CCR1;
        break;
    default:
        break;
    }
}
