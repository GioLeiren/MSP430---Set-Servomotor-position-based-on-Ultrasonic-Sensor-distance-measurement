#ifndef __LEDS_H
#define __LEDS_H
#include <stdint.h>

void ledsConfig(void);

#endif
