#ifndef __SERVOMOTOR_H
#define __SERVOMOTOR_H
#include <stdint.h>

void Servo_Config(void);
void Servo_SetPosition(unsigned int position);

#endif
