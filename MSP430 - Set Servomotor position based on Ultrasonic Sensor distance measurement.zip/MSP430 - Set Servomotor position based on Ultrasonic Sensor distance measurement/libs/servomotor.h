#ifndef __SERVOMOTOR_H
#define __SERVOMOTOR_H
#include <stdint.h>

void servoConfig(void);
void servoSetPosition(unsigned int position);

#endif
