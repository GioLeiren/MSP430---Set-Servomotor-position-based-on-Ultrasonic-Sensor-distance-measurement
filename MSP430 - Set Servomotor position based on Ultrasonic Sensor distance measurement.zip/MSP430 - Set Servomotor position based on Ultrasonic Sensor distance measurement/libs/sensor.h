#ifndef __SENSOR_H_
#define __SENSOR_H_
#include <stdint.h>

void sensorConfig();
float sensorTriggerPulse();

#endif
