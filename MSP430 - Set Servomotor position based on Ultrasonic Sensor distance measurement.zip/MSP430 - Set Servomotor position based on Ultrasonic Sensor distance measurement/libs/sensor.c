#include <msp430.h>
#include <stdint.h>
#include "sensor.h"

void sensorConfig(){
    P1DIR |= BIT4;              // Pino 1.4 (trigger) como sa�da
    P1DIR &= ~BIT5;             // Pino 1.5 (echo) como entrada
    P1SEL |= BIT5;              // Pino 1.5 (echo) para timer de captura

    P1IE |= BIT5;               // Habilitar interrup��o para pino 1.5 (echo)
    P1IES &= ~BIT5;             // Interrup��o em flanco de subida
    P1IFG &= ~BIT5;             // Limpar flag de interrup��o
}

void sensorTriggerPulse(){
    {
        // Mandar sinal do trigger
        P1OUT |= BIT4;
        __delay_cycles(10);
        P1OUT &= ~BIT4;

        // Esperar o sinal do echo
        __delay_cycles(30000);

    }
}

